import { Component, OnInit } from '@angular/core';
import {SearchService} from '../services/search.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  constructor(private searchService:SearchService) { }
  searchNav:string;

  ngOnInit(): void {
  }

  Search(){
    console.log(this.searchNav)
    this.searchService.textSearch=this.searchNav;
  }

}
