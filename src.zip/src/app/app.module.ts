import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {Routes,RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PersonComponent } from './person/person.component';
import { NavComponent } from './nav/nav.component';
import { PostComponent } from './post/post.component';
import { AlertifyService } from './services/alertify.service';
import { PostPipe } from './post/post.pipe';
import { SearchService } from './services/search.service';

const routes:Routes=[
  {path:"",redirectTo:"posts",pathMatch:"full"},
  {path:"posts",component:PostComponent},
  {path:"person",component:PersonComponent},
  {path:"posts/:userid",component:PostComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    PersonComponent,
    NavComponent,
    PostComponent,
    PostPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AlertifyService,SearchService],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
