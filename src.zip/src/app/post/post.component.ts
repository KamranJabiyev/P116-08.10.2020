import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Post} from './Post';
import { User } from './User';
import {ActivatedRoute} from '@angular/router';
import { PostService } from './post.service';
import { AlertifyService } from '../services/alertify.service';
import {SearchService} from '../services/search.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css'],
  providers:[PostService]
})
export class PostComponent implements OnInit {

  constructor(private http:HttpClient,
    private activatedRoute:ActivatedRoute,
    private postService:PostService,
    private alertifyService:AlertifyService,
    private searchService:SearchService) {
      
    }

  posts:Post[]=[];
  users:User[]=[];
  path:string="https://jsonplaceholder.typicode.com/";
  isSelected:boolean=false;
  today:number;
  text:string;

  SearchText():string{
    return this.searchService.textSearch;
  }

  ngOnInit(): void {
    this.today= Date.now();
    this.activatedRoute.params.subscribe(params=>{
      this.getPosts(params["userid"])
    })
    this.getUsers();
  }

  addFavorite(title:string){
    this.isSelected=true;
    this.alertifyService.error(title)
  }

  getPosts(userid){
    if(userid){
      this.postService.GetAllPost(userid).subscribe(data=>{
        this.posts=data;
      })
    }else{
      this.postService.GetAllPost().subscribe(data=>{
        this.posts=data;
      })
    }
  }



  getUsers(){
    this.http.get<User[]>(this.path+"users").subscribe(res=>{
      this.users=res;
    })
  }

}
