import { Pipe, PipeTransform } from '@angular/core';
import { Post } from './Post';

@Pipe({
  name: 'post'
})
export class PostPipe implements PipeTransform {

  transform(value: Post[], text: string): Post[] {
    console.log("Yes")
    if(!text){
      return value;
    }else{
      return value.filter(p=>p.title.toLocaleLowerCase()
      .indexOf(text.toLocaleLowerCase())!=-1)
    }
  }

}
